<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: ../../html/auth/login.html");
    exit();
}

// Verificar que el usuario sea cliente
if ($_SESSION['user_type'] != 'cliente') {
    header("Location: profesional.php");
    exit();
}

require '../../../conexion.php';

// Obtener servicios disponibles
$sql = "SELECT s.*, u.nombre_completo FROM servicios_publicados s 
        INNER JOIN usuarios u ON s.user_id = u.id 
        ORDER BY s.fecha_publicacion DESC";
$result = $con->query($sql);

// Incluir el template HTML
include '../../html/dashboard/cliente.html';

$con->close();
?> 