<?php
session_start();

// Configuración para phpMyAdmin
$servidor = "localhost"; 
$usuario = "root"; // Usuario por defecto de phpMyAdmin
$password = ""; // Contraseña vacía por defecto en XAMPP/WAMP
$BD = "conecta_cusco_db"; 

$con = mysqli_connect($servidor, $usuario, $password, $BD);

if (!$con) {
    die("ERROR: No se pudo conectar a la base de datos. " . mysqli_connect_error());
}

mysqli_set_charset($con, "utf8mb4");

$mensaje_estado = "";
$clase_mensaje = "";

if (isset($_POST['correo_electronico']) && isset($_POST['contrasena'])) {
    $email = trim($_POST['correo_electronico']);
    $password = $_POST['contrasena'];

    // Buscar el usuario en la base de datos
    $sql = "SELECT id, nombre_completo, correo_electronico, contrasena_hash, tipo_cuenta FROM usuarios WHERE correo_electronico = ?";
    $stmt = mysqli_prepare($con, $sql);
    mysqli_stmt_bind_param($stmt, "s", $email);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);

    if ($user = mysqli_fetch_assoc($result)) {
        // Verificar la contraseña
        if ($user && password_verify($password, $user['contrasena_hash'])) {
            // Iniciar sesión
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['user_email'] = $user['correo_electronico'];
            $_SESSION['user_name'] = $user['nombre_completo'];
            $_SESSION['user_type'] = $user['tipo_cuenta'];
            
            // Redirigir a perfil.html después del login exitoso
            header("Location: ../html/perfil.html");
            exit();
        } else {
            $mensaje_estado = "Contraseña incorrecta.";
            $clase_mensaje = "error";
        }
    } else {
        $mensaje_estado = "No existe una cuenta con este correo electrónico.";
        $clase_mensaje = "error";
    }
    mysqli_stmt_close($stmt);
}

mysqli_close($con);

// Si hay errores, redirigir con mensaje
if (!empty($mensaje_estado)) {
    header("Location: ../html/login.html?mensaje=" . urlencode($mensaje_estado) . "&tipo=error");
    exit();
}
?>
