<?php

echo "Hola" .$_POST['buscar'];

?>