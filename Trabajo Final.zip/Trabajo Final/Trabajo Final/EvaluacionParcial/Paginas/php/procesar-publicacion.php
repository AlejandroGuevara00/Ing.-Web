<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.html");
    exit();
}

// Verificar que el usuario sea profesional
if ($_SESSION['user_type'] != 'profesional') {
    header("Location: dashboard-cliente.php");
    exit();
}

require '../conexion.php';

$user_id = $_SESSION['user_id'];
$titulo = trim($_POST['service-title'] ?? '');
$categoria = trim($_POST['category'] ?? '');
$descripcion = trim($_POST['description'] ?? '');
$cobertura = trim($_POST['service-area'] ?? '');
$telefono = trim($_POST['contact-phone'] ?? '');
$email = trim($_POST['contact-email'] ?? '');

// Validar campos obligatorios
if (empty($titulo) || empty($categoria) || empty($descripcion) || empty($cobertura)) {
    die("Error: Todos los campos son obligatorios.");
}

// Validar email
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    die("Error: El formato del email no es válido.");
}

// Manejar imagen con validación
$foto_nombre = '';
if (!empty($_FILES['profile-photo']['name'])) {
    $archivo = $_FILES['profile-photo'];
    $nombre_archivo = $archivo['name'];
    $tipo_archivo = $archivo['type'];
    $tamano_archivo = $archivo['size'];
    $archivo_temporal = $archivo['tmp_name'];
    
    // Validar tipo de archivo
    $tipos_permitidos = ['image/jpeg', 'image/jpg', 'image/png', 'image/gif', 'image/webp'];
    if (!in_array($tipo_archivo, $tipos_permitidos)) {
        die("Error: Solo se permiten archivos de imagen (JPG, PNG, GIF, WEBP).");
    }
    
    // Validar tamaño (máximo 5MB)
    if ($tamano_archivo > 5 * 1024 * 1024) {
        die("Error: El archivo es demasiado grande. Máximo 5MB.");
    }
    
    // Generar nombre único
    $extension = pathinfo($nombre_archivo, PATHINFO_EXTENSION);
    $foto_nombre = uniqid() . '_' . time() . '.' . $extension;
    $ruta_destino = '../uploads/' . $foto_nombre;
    
    // Crear directorio si no existe
    if (!is_dir('../uploads/')) {
        mkdir('../uploads/', 0755, true);
    }
    
    // Mover archivo
    if (!move_uploaded_file($archivo_temporal, $ruta_destino)) {
        die("Error: No se pudo subir el archivo.");
    }
}

// Insertar en la base de datos
$sql = "INSERT INTO servicios_publicados 
    (user_id, titulo, categoria, descripcion, cobertura, telefono, email, foto_perfil, fecha_publicacion) 
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, NOW())";

$stmt = $con->prepare($sql);
if (!$stmt) {
    die("Error al preparar la consulta: " . $con->error);
}

$stmt->bind_param("isssssss", $user_id, $titulo, $categoria, $descripcion, $cobertura, $telefono, $email, $foto_nombre);

if ($stmt->execute()) {
    // Redirigir al dashboard del profesional
    header("Location: ../dashboard/profesional.php");
    exit();
} else {
    $error = "Error al publicar el servicio: " . $stmt->error;
}

$stmt->close();
$con->close();
?>
