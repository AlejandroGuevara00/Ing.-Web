<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: ../../html/auth/login.html");
    exit();
}

// Verificar que el usuario sea profesional
if ($_SESSION['user_type'] != 'profesional') {
    header("Location: cliente.php");
    exit();
}

require '../../../conexion.php';

// Obtener servicios del profesional
$user_id = $_SESSION['user_id'];
$sql = "SELECT * FROM servicios_publicados WHERE user_id = ? ORDER BY fecha_publicacion DESC";
$stmt = $con->prepare($sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();

// Incluir el template HTML
include '../../html/dashboard/profesional.html';

$stmt->close();
$con->close();
?> 