<?php
// Configuración para phpMyAdmin
$servidor = "localhost";
$usuario = "root"; // Usuario por defecto de phpMyAdmin
$password = ""; // Contraseña vacía por defecto en XAMPP/WAMP
$BD = "conecta_cusco_db";

// Intenta conectar con MySQLi orientado a objetos
try {
    $con = new mysqli($servidor, $usuario, $password, $BD);
    $con->set_charset("utf8mb4");
} catch (mysqli_sql_exception $e) {
    die("Error de conexión: " . $e->getMessage());
}

mysqli_set_charset($con, "utf8mb4");

$mensaje_estado = "";
$clase_mensaje = ""; 
$nombre_completo = '';
$correo_electronico = '';
$tipo_cuenta = 'cliente'; // Valor por defecto

if (isset($_POST['registro'])) {
    $nombre_completo = trim($_POST['nombre_completo'] ?? '');
    $correo_electronico = trim($_POST['correo_electronico'] ?? '');
    $password = $_POST['contrasena'] ?? ''; 
    $confirm_password = $_POST['confirmar_contrasena'] ?? ''; 
    $tipo_cuenta = ($_POST['tipo_cuenta'] == 'profesional') ? 'profesional' : 'cliente';

    // Validación de datos
    if (empty($nombre_completo) || empty($correo_electronico) || empty($password) || empty($confirm_password)) {
        $mensaje_estado = "Todos los campos son obligatorios.";
        $clase_mensaje = "error";
    } elseif (strlen($nombre_completo) < 3) {
        $mensaje_estado = "El nombre debe tener al menos 3 caracteres.";
        $clase_mensaje = "error";
    } elseif (!filter_var($correo_electronico, FILTER_VALIDATE_EMAIL)) {
        $mensaje_estado = "El formato del correo electrónico no es válido.";
        $clase_mensaje = "error";
    } elseif (strlen($password) < 6) {
        $mensaje_estado = "La contraseña debe tener al menos 6 caracteres.";
        $clase_mensaje = "error";
    } elseif ($password !== $confirm_password) {
        $mensaje_estado = "Las contraseñas no coinciden.";
        $clase_mensaje = "error";
        $password = '';
        $confirm_password = '';
    } else {
        $password_hash = password_hash($password, PASSWORD_DEFAULT);

        $sql = "INSERT INTO usuarios (nombre_completo, correo_electronico, contrasena_hash, tipo_cuenta) VALUES (?, ?, ?, ?)";

        if ($stmt = mysqli_prepare($con, $sql)) {
            mysqli_stmt_bind_param($stmt, "ssss", $param_nombre_completo, $param_correo_electronico, $param_password_hash, $param_tipo_cuenta);

            $param_nombre_completo = $nombre_completo;
            $param_correo_electronico = $correo_electronico;
            $param_password_hash = $password_hash;
            $param_tipo_cuenta = $tipo_cuenta;

            if (mysqli_stmt_execute($stmt)) {
                $mensaje_estado = "¡Registro exitoso! Ahora puedes iniciar sesión.";
                $clase_mensaje = "success";
                
                // Redirigir con mensaje de éxito
                header("Location: ../html/registro.html?mensaje=" . urlencode($mensaje_estado) . "&tipo=success");
                exit();
            } else {
                if (mysqli_errno($con) == 1062) {
                    $mensaje_estado = "El correo electrónico ya está registrado. Por favor, utiliza otro.";
                    $clase_mensaje = "error";
                } else {
                    $mensaje_estado = "Algo salió mal al registrar. Por favor, inténtalo de nuevo más tarde.";
                    $clase_mensaje = "error";
                }
                
                // Redirigir con mensaje de error
                header("Location: ../html/registro.html?mensaje=" . urlencode($mensaje_estado) . "&tipo=error");
                exit();
            }

            mysqli_stmt_close($stmt);
        } else {
            $mensaje_estado = "Error al preparar la consulta.";
            $clase_mensaje = "error";
            
            // Redirigir con mensaje de error
            header("Location: ../html/registro.html?mensaje=" . urlencode($mensaje_estado) . "&tipo=error");
            exit();
        }
    }
} else {
    // Si no hay POST, redirigir al formulario
    header("Location: ../html/registro.html");
    exit();
}

mysqli_close($con);
?> 