# Conecta Cusco - Plataforma de Servicios Locales

## Descripción
Conecta Cusco es una plataforma web que conecta profesionales locales con clientes en la ciudad de Cusco, Perú. Permite a los profesionales publicar sus servicios y a los clientes encontrar y contactar profesionales calificados.

## Características
- ✅ Registro de usuarios (clientes y profesionales)
- ✅ Sistema de autenticación seguro
- ✅ Publicación de servicios por profesionales
- ✅ Búsqueda de servicios por categorías
- ✅ Dashboard personalizado para cada tipo de usuario
- ✅ Subida de imágenes de perfil
- ✅ Interfaz responsive y moderna

## Requisitos del Sistema
- **XAMPP, WAMP, o similar** (con phpMyAdmin)
- PHP 7.4 o superior
- MySQL 5.7 o superior
- Servidor web (Apache/Nginx)
- Extensiones PHP: mysqli, session, fileinfo

## Instalación Rápida (phpMyAdmin)

### 1. Configurar XAMPP/WAMP
1. Instalar XAMPP o WAMP
2. Iniciar Apache y MySQL desde el panel de control
3. Verificar que phpMyAdmin esté accesible en `http://localhost/phpmyadmin`

### 2. Configurar el Proyecto
1. Copiar el proyecto a: `C:\xampp\htdocs\EvaluacionParcial\`
2. Ejecutar el script de configuración automática:
   ```
   http://localhost/EvaluacionParcial/Paginas/CreacionDB.php
   ```
3. Verificar que se hayan creado todas las tablas en phpMyAdmin

### 3. Acceder al Proyecto
- **URL principal**: `http://localhost/EvaluacionParcial/`
- **Registro**: `http://localhost/EvaluacionParcial/Paginas/registro.php`
- **Login**: `http://localhost/EvaluacionParcial/Paginas/login.html`

## Configuración de Base de Datos

### Credenciales por Defecto (phpMyAdmin)
```php
$servidor = "localhost";
$usuario = "root";
$password = ""; // Vacía por defecto en XAMPP/WAMP
$BD = "conecta_cusco_db";
```

### Creación Manual (Opcional)
1. Abrir phpMyAdmin: `http://localhost/phpmyadmin`
2. Crear nueva base de datos: `conecta_cusco_db`
3. Cotejación: `utf8mb4_unicode_ci`
4. Ejecutar el script `CreacionDB.php` para crear las tablas

## Estructura del Proyecto
```
EvaluacionParcial/
├── conexion.php              # Configuración para phpMyAdmin
├── index.html                # Página principal
├── .htaccess                 # Configuración de Apache
├── README.md                 # Este archivo
├── configuracion-phpmyadmin.md # Guía específica de phpMyAdmin
├── Estilos/                  # Archivos CSS
├── Imagenes/                 # Imágenes del sitio
├── js/                       # Archivos JavaScript
├── uploads/                  # Archivos subidos por usuarios
└── Paginas/                  # Páginas PHP del sistema
    ├── CreacionDB.php        # Script de creación de BD
    ├── registro.php          # Registro de usuarios
    ├── login.php             # Autenticación
    ├── dashboard-cliente.php # Panel de cliente
    ├── dashboard-profesional.php # Panel de profesional
    └── ...                   # Otras páginas
```

## Uso

### Para Clientes
1. Registrarse en la plataforma
2. Buscar servicios por categoría o ubicación
3. Contactar profesionales directamente
4. Ver perfiles y reseñas

### Para Profesionales
1. Registrarse como profesional
2. Completar perfil con información detallada
3. Publicar servicios con descripción y precios
4. Gestionar contactos de clientes

## Credenciales de Prueba
- **Profesional**: juan@ejemplo.com / 123456
- **Cliente**: maria@ejemplo.com / 123456

## Seguridad
- Contraseñas hasheadas con `password_hash()`
- Validación de entrada de datos
- Protección contra SQL Injection
- Validación de tipos de archivo
- Configuración de seguridad en `.htaccess`

## Tecnologías Utilizadas
- **Backend**: PHP 7.4+
- **Base de Datos**: MySQL (phpMyAdmin)
- **Frontend**: HTML5, CSS3, JavaScript
- **Servidor Local**: XAMPP/WAMP
- **Seguridad**: Password hashing, Prepared statements

## Solución de Problemas

### Error de Conexión a Base de Datos
- Verificar que XAMPP/WAMP esté ejecutándose
- Comprobar que MySQL esté iniciado
- Verificar credenciales en `conexion.php`
- Asegurar que la base de datos existe

### Error de Subida de Archivos
- Verificar permisos del directorio `uploads/`
- Asegurar que `upload_max_filesize` en PHP sea suficiente
- Verificar que el directorio sea escribible

### Páginas no Cargando
- Verificar que Apache esté ejecutándose
- Comprobar que el proyecto esté en la carpeta correcta
- Revisar logs de error de XAMPP/WAMP
- Verificar que PHP esté habilitado

### phpMyAdmin no Accesible
- Verificar que MySQL esté iniciado
- Comprobar puerto 3306 (MySQL) y 80/443 (Apache)
- Reiniciar servicios desde el panel de control

## Archivos Importantes
- `configuracion-phpmyadmin.md` - Guía detallada de configuración
- `Paginas/CreacionDB.php` - Script de configuración automática
- `conexion.php` - Configuración de base de datos

## Contribución
Para contribuir al proyecto:
1. Fork el repositorio
2. Crear una rama para tu feature
3. Hacer commit de tus cambios
4. Crear un Pull Request

## Licencia
Este proyecto está bajo la Licencia MIT.

## Contacto
Para soporte técnico o consultas, contactar al equipo de desarrollo. 