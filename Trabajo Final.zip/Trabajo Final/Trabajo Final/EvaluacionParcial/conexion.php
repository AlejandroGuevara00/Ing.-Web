<?php
// Configuración para phpMyAdmin
$servidor = "localhost";
$usuario = "root"; // Usuario por defecto de phpMyAdmin
$password = ""; // Contraseña vacía por defecto en XAMPP/WAMP
$BD = "conecta_cusco_db";

// Intenta conectar con MySQLi orientado a objetos
try {
    $con = new mysqli($servidor, $usuario, $password, $BD);
    $con->set_charset("utf8mb4");
    
    if ($con->connect_error) {
        throw new Exception("Error de conexión: " . $con->connect_error);
    }
} catch (Exception $e) {
    die("Error de conexión: " . $e->getMessage());
}

// Función para cerrar la conexión
function cerrarConexion($conexion) {
    if ($conexion) {
        $conexion->close();
    }
}
?> 