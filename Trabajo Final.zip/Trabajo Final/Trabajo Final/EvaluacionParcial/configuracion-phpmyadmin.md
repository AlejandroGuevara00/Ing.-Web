# Configuración para phpMyAdmin - Conecta Cusco

## Requisitos Previos
- XAMPP, WAMP, o similar instalado
- phpMyAdmin accesible
- PHP 7.4 o superior

## Pasos de Configuración

### 1. Iniciar Servicios
1. Abrir XAMPP Control Panel
2. Iniciar Apache
3. Iniciar MySQL
4. Verificar que ambos servicios estén en verde

### 2. Acceder a phpMyAdmin
1. Abrir navegador
2. Ir a: `http://localhost/phpmyadmin`
3. Usuario: `root`
4. Contraseña: (dejar vacía por defecto)

### 3. Crear Base de Datos Manualmente (Opcional)
Si prefieres crear la base de datos manualmente:

1. En phpMyAdmin, hacer clic en "Nueva"
2. Nombre de la base de datos: `conecta_cusco_db`
3. Cotejación: `utf8mb4_unicode_ci`
4. Hacer clic en "Crear"

### 4. Ejecutar Script Automático
1. Colocar el proyecto en: `C:\xampp\htdocs\EvaluacionParcial\`
2. Abrir navegador
3. Ir a: `http://localhost/EvaluacionParcial/Paginas/CreacionDB.php`
4. Verificar que todas las tablas se creen correctamente

### 5. Verificar Configuración
En phpMyAdmin deberías ver:
- Base de datos: `conecta_cusco_db`
- Tablas:
  - `usuarios`
  - `servicios_publicados`
  - `resenas`
  - `contactos`

## Credenciales de Conexión
```php
$servidor = "localhost";
$usuario = "root";
$password = "";
$BD = "conecta_cusco_db";
```

## Credenciales de Prueba
- **Profesional**: juan@ejemplo.com / 123456
- **Cliente**: maria@ejemplo.com / 123456

## Solución de Problemas

### Error de Conexión
- Verificar que MySQL esté ejecutándose
- Verificar credenciales en `conexion.php`
- Comprobar que la base de datos existe

### Error de Permisos
- En XAMPP: Usuario `root` sin contraseña
- En WAMP: Usuario `root` sin contraseña
- En otros: Verificar configuración local

### Archivos no Encontrados
- Verificar que el proyecto esté en la carpeta correcta
- Comprobar rutas en los archivos PHP
- Verificar permisos de archivos

## Acceso al Proyecto
Una vez configurado:
- URL: `http://localhost/EvaluacionParcial/`
- Página principal: `http://localhost/EvaluacionParcial/index.html`
- Registro: `http://localhost/EvaluacionParcial/Paginas/registro.php`
- Login: `http://localhost/EvaluacionParcial/Paginas/login.html`

## Estructura de Archivos
```
C:\xampp\htdocs\EvaluacionParcial\
├── conexion.php              # Configuración para phpMyAdmin
├── index.html                # Página principal
├── Paginas\
│   ├── CreacionDB.php        # Script de configuración
│   ├── registro.php          # Registro de usuarios
│   └── ...                   # Otras páginas
└── ...                       # Otros archivos
``` 