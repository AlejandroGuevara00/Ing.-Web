<?php
// Script de verificación de configuración para phpMyAdmin
echo "<h1>🔍 Verificación de Configuración - Conecta Cusco</h1>";
echo "<style>
    body { font-family: Arial, sans-serif; margin: 20px; }
    .success { color: green; }
    .error { color: red; }
    .warning { color: orange; }
    .info { color: blue; }
    .check { margin: 10px 0; padding: 10px; border-left: 4px solid #ccc; }
</style>";

// Verificar PHP
echo "<div class='check'>";
echo "<h3>📋 Verificación de PHP</h3>";
echo "Versión de PHP: <strong>" . phpversion() . "</strong>";
if (version_compare(PHP_VERSION, '7.4.0') >= 0) {
    echo " <span class='success'>✅ Compatible</span>";
} else {
    echo " <span class='error'>❌ Se requiere PHP 7.4 o superior</span>";
}
echo "</div>";

// Verificar extensiones
echo "<div class='check'>";
echo "<h3>🔧 Extensiones PHP</h3>";
$extensiones_requeridas = ['mysqli', 'session', 'fileinfo'];
foreach ($extensiones_requeridas as $ext) {
    if (extension_loaded($ext)) {
        echo "✅ $ext: <span class='success'>Disponible</span><br>";
    } else {
        echo "❌ $ext: <span class='error'>No disponible</span><br>";
    }
}
echo "</div>";

// Verificar conexión a base de datos
echo "<div class='check'>";
echo "<h3>🗄️ Conexión a Base de Datos</h3>";

$servidor = "localhost";
$usuario = "root";
$password = "";

try {
    $con = new mysqli($servidor, $usuario, $password);
    if ($con->connect_error) {
        throw new Exception("Error de conexión: " . $con->connect_error);
    }
    echo "✅ Conexión a MySQL: <span class='success'>Exitosa</span><br>";
    
    // Verificar base de datos
    $result = $con->query("SHOW DATABASES LIKE 'conecta_cusco_db'");
    if ($result->num_rows > 0) {
        echo "✅ Base de datos 'conecta_cusco_db': <span class='success'>Existe</span><br>";
        
        // Verificar tablas
        $con->select_db("conecta_cusco_db");
        $tablas_requeridas = ['usuarios', 'servicios_publicados', 'resenas', 'contactos'];
        foreach ($tablas_requeridas as $tabla) {
            $result = $con->query("SHOW TABLES LIKE '$tabla'");
            if ($result->num_rows > 0) {
                echo "✅ Tabla '$tabla': <span class='success'>Existe</span><br>";
            } else {
                echo "❌ Tabla '$tabla': <span class='error'>No existe</span><br>";
            }
        }
    } else {
        echo "❌ Base de datos 'conecta_cusco_db': <span class='error'>No existe</span><br>";
        echo "<span class='warning'>💡 Ejecuta: <a href='Paginas/CreacionDB.php'>CreacionDB.php</a></span><br>";
    }
    
    $con->close();
} catch (Exception $e) {
    echo "❌ Conexión a MySQL: <span class='error'>Fallida</span><br>";
    echo "<span class='error'>Error: " . $e->getMessage() . "</span><br>";
    echo "<span class='warning'>💡 Verifica que XAMPP/WAMP esté ejecutándose</span><br>";
}

echo "</div>";

// Verificar directorios
echo "<div class='check'>";
echo "<h3>📁 Directorios del Proyecto</h3>";
$directorios = [
    'uploads' => 'Para archivos subidos',
    'js' => 'Para archivos JavaScript',
    'Estilos' => 'Para archivos CSS',
    'Imagenes' => 'Para imágenes del sitio',
    'Paginas' => 'Para páginas PHP'
];

foreach ($directorios as $dir => $descripcion) {
    if (is_dir($dir)) {
        echo "✅ $dir: <span class='success'>Existe</span> - $descripcion<br>";
        if ($dir === 'uploads' && is_writable($dir)) {
            echo "✅ Permisos de escritura en $dir: <span class='success'>Correctos</span><br>";
        } elseif ($dir === 'uploads') {
            echo "❌ Permisos de escritura en $dir: <span class='error'>Incorrectos</span><br>";
        }
    } else {
        echo "❌ $dir: <span class='error'>No existe</span> - $descripcion<br>";
    }
}
echo "</div>";

// Verificar archivos importantes
echo "<div class='check'>";
echo "<h3>📄 Archivos Importantes</h3>";
$archivos = [
    'conexion.php' => 'Configuración de base de datos',
    'index.html' => 'Página principal',
    'js/script.js' => 'JavaScript del sitio',
    'Paginas/registro.php' => 'Registro de usuarios',
    'Paginas/login.php' => 'Sistema de login',
    'Paginas/CreacionDB.php' => 'Script de configuración'
];

foreach ($archivos as $archivo => $descripcion) {
    if (file_exists($archivo)) {
        echo "✅ $archivo: <span class='success'>Existe</span> - $descripcion<br>";
    } else {
        echo "❌ $archivo: <span class='error'>No existe</span> - $descripcion<br>";
    }
}
echo "</div>";

// Resumen
echo "<div class='check'>";
echo "<h3>📊 Resumen</h3>";
echo "<p><strong>Para usar el proyecto:</strong></p>";
echo "<ol>";
echo "<li>Instala XAMPP o WAMP</li>";
echo "<li>Inicia Apache y MySQL</li>";
echo "<li>Ejecuta <a href='Paginas/CreacionDB.php'>CreacionDB.php</a></li>";
echo "<li>Accede a <a href='index.html'>index.html</a></li>";
echo "</ol>";
echo "<p><strong>URLs importantes:</strong></p>";
echo "<ul>";
echo "<li><a href='index.html'>Página principal</a></li>";
echo "<li><a href='Paginas/registro.php'>Registro</a></li>";
echo "<li><a href='Paginas/login.html'>Login</a></li>";
echo "<li><a href='Paginas/CreacionDB.php'>Configurar BD</a></li>";
echo "</ul>";
echo "</div>";

echo "<div class='check'>";
echo "<h3>🔑 Credenciales de Prueba</h3>";
echo "<p><strong>Profesional:</strong> juan@ejemplo.com / 123456</p>";
echo "<p><strong>Cliente:</strong> maria@ejemplo.com / 123456</p>";
echo "</div>";
?> 