<?php
echo "<h1>Verificación de Reorganización - Conecta Cusco</h1>";
echo "<h2>Estructura de Archivos Reorganizada</h2>";

// Verificar estructura de carpetas
$estructura_esperada = [
    'Paginas/php/auth' => ['login.php', 'logout.php', 'registro.php'],
    'Paginas/php/dashboard' => ['cliente.php', 'profesional.php'],
    'Paginas/php/database' => ['CreacionDB.php'],
    'Paginas/php/servicios' => ['procesar-publicacion.php'],
    'Paginas/html/auth' => ['login.html', 'registro.html'],
    'Paginas/html/dashboard' => ['cliente.html', 'profesional.html'],
    'Paginas/html/servicios' => ['buscar.html', 'buscar-servicios.html', 'perfil.html', 'publicar.html']
];

echo "<h3>Verificando estructura de archivos:</h3>";
$todos_existen = true;

foreach ($estructura_esperada as $carpeta => $archivos) {
    echo "<h4>$carpeta:</h4>";
    if (!is_dir($carpeta)) {
        echo "<p style='color: red;'>❌ Carpeta no existe: $carpeta</p>";
        $todos_existen = false;
    } else {
        echo "<p style='color: green;'>✅ Carpeta existe: $carpeta</p>";
        foreach ($archivos as $archivo) {
            $ruta_completa = $carpeta . '/' . $archivo;
            if (file_exists($ruta_completa)) {
                echo "<p style='color: green;'>  ✅ $archivo</p>";
            } else {
                echo "<p style='color: red;'>  ❌ $archivo (no encontrado)</p>";
                $todos_existen = false;
            }
        }
    }
}

// Verificar archivos principales
echo "<h3>Verificando archivos principales:</h3>";
$archivos_principales = [
    'index.html',
    'conexion.php',
    'js/script.js'
];

foreach ($archivos_principales as $archivo) {
    if (file_exists($archivo)) {
        echo "<p style='color: green;'>✅ $archivo</p>";
    } else {
        echo "<p style='color: red;'>❌ $archivo (no encontrado)</p>";
        $todos_existen = false;
    }
}

// Verificar rutas en archivos clave
echo "<h3>Verificando rutas actualizadas:</h3>";

// Verificar index.html
if (file_exists('index.html')) {
    $contenido_index = file_get_contents('index.html');
    if (strpos($contenido_index, 'Paginas/html/auth/login.html') !== false) {
        echo "<p style='color: green;'>✅ Rutas en index.html actualizadas</p>";
    } else {
        echo "<p style='color: red;'>❌ Rutas en index.html no actualizadas</p>";
        $todos_existen = false;
    }
}

// Verificar login.php
if (file_exists('Paginas/php/auth/login.php')) {
    $contenido_login = file_get_contents('Paginas/php/auth/login.php');
    if (strpos($contenido_login, '../dashboard/profesional.php') !== false) {
        echo "<p style='color: green;'>✅ Rutas en login.php actualizadas</p>";
    } else {
        echo "<p style='color: red;'>❌ Rutas en login.php no actualizadas</p>";
        $todos_existen = false;
    }
}

// Verificar logout.php
if (file_exists('Paginas/php/auth/logout.php')) {
    $contenido_logout = file_get_contents('Paginas/php/auth/logout.php');
    if (strpos($contenido_logout, '../../html/auth/login.html') !== false) {
        echo "<p style='color: green;'>✅ Rutas en logout.php actualizadas</p>";
    } else {
        echo "<p style='color: red;'>❌ Rutas en logout.php no actualizadas</p>";
        $todos_existen = false;
    }
}

echo "<h3>Resumen:</h3>";
if ($todos_existen) {
    echo "<p style='color: green; font-weight: bold;'>🎉 ¡Reorganización completada exitosamente!</p>";
    echo "<p>La estructura de archivos ha sido reorganizada correctamente:</p>";
    echo "<ul>";
    echo "<li><strong>PHP puro:</strong> Paginas/php/ (auth, dashboard, database, servicios)</li>";
    echo "<li><strong>HTML puro:</strong> Paginas/html/ (auth, dashboard, servicios)</li>";
    echo "<li><strong>Archivos mixtos:</strong> Separados en PHP + HTML templates</li>";
    echo "</ul>";
    echo "<p><strong>Beneficios de la reorganización:</strong></p>";
    echo "<ul>";
    echo "<li>Separación clara entre lógica (PHP) y presentación (HTML)</li>";
    echo "<li>Mejor organización por funcionalidad</li>";
    echo "<li>Facilita el mantenimiento y desarrollo</li>";
    echo "<li>Estructura más profesional y escalable</li>";
    echo "</ul>";
} else {
    echo "<p style='color: red; font-weight: bold;'>⚠️ Hay problemas en la reorganización. Revisa los errores arriba.</p>";
}

echo "<h3>Próximos pasos:</h3>";
echo "<ol>";
echo "<li>Probar la funcionalidad del sitio web</li>";
echo "<li>Verificar que todas las rutas funcionen correctamente</li>";
echo "<li>Actualizar documentación si es necesario</li>";
echo "</ol>";
?> 